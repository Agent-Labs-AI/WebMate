import { normalizeRuntimeTraceConfig } from './runtime-config.js';
import { buildPromptTraceProvenance } from './prompt-provenance.js';
import { formatErrorMessage } from '../error-format.js';
import { TRACE_FORMAT_VERSION, makeEvent } from './event-model.js';
import { normalizeErrorCode } from './error-codes.js';
import { normalizeRunHeader, effectiveDelegationDepth } from './run-header.js';
import { clampUtf8Value, fitUtf8Prefix, utf8ByteLength } from './utf8-budget.js';
import {
  buildTraceRepairPlan,
  isStaleRunningTrace,
  normalizedThreshold,
  TRACE_REPAIR_STALE_AFTER_MS,
} from './repair.js';
import { createTraceStats, addTraceEvent, aggregateTraceRuns } from './stats.js';

/**
 * Trace recorder — writes per-run traces (LLM requests/responses, tool calls,
 * screenshots) into IndexedDB for later inspection and cross-model comparison.
 *
 * Schema (db `webbrain_traces`, v2):
 *   - runs       keyPath=runId                  // top-level run metadata
 *   - events     keyPath=[runId, seq]           // ordered event log
 *   - shots      keyPath=[runId, seq]           // screenshot Blobs
 *
 * All writes are fire-and-forget. Recording is gated on the `tracingEnabled`
 * setting. When disabled, every call is a cheap no-op.
 */

const DB_NAME = 'webbrain_traces';
const DB_VERSION = 2;

// Lossless tier bounds: tool results up to 200 KB verbatim, request payloads
// up to 500 KB before the head is clamped with a truncation marker. Keeps an
// opt-in debugging tier from exhausting IndexedDB on a single long run.
const LOSSILESS_RESULT_CAP = 200_000;
const LOSSILESS_REQUEST_CAP = 500_000;
const LOSSILESS_RUN_CAP = 5_000_000;
const LOSSILESS_TOTAL_CAP = 50_000_000;

let _dbPromise = null;
function openDB() {
  if (_dbPromise) return _dbPromise;
  _dbPromise = new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains('runs')) {
        const s = db.createObjectStore('runs', { keyPath: 'runId' });
        s.createIndex('startedAt', 'startedAt');
        s.createIndex('model', 'model');
        s.createIndex('providerId', 'providerId');
      }
      // v2: lineage lookup indexes. `conversationId` IS the session identity
      // (grouping key for sibling runs); the index carries the semantic name
      // so session-level queries read naturally. Records with null keys are
      // skipped by IndexedDB, so old runs are simply absent from the index.
      const runsStore = req.transaction ? req.transaction.objectStore('runs') : null;
      if (runsStore) {
        if (!runsStore.indexNames.contains('sessionId')) {
          runsStore.createIndex('sessionId', 'conversationId');
        }
        if (!runsStore.indexNames.contains('parentRunId')) {
          runsStore.createIndex('parentRunId', 'parentRunId');
        }
      }
      if (!db.objectStoreNames.contains('events')) {
        const s = db.createObjectStore('events', { keyPath: ['runId', 'seq'] });
        s.createIndex('runId', 'runId');
      }
      if (!db.objectStoreNames.contains('shots')) {
        const s = db.createObjectStore('shots', { keyPath: ['runId', 'seq'] });
        s.createIndex('runId', 'runId');
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
  return _dbPromise;
}

function tx(db, stores, mode = 'readwrite') {
  return db.transaction(stores, mode);
}

function promisifyReq(req) {
  return new Promise((resolve, reject) => {
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

// ----- Settings gate ---------------------------------------------------------

async function tracingEnabled() {
  try {
    if (typeof indexedDB === 'undefined') return false;
    const storageApi = (typeof browser !== 'undefined' ? browser : chrome).storage.local;
    const { tracingEnabled } = await storageApi.get(['tracingEnabled']);
    return tracingEnabled === true;
  } catch { return false; }
}

// Opt-in lossless tier: same event pipeline, full request payloads instead of
// content-free provenance. Read once per run at startRun; never per event.
async function losslessTraceEnabled() {
  try {
    if (typeof indexedDB === 'undefined') return false;
    const storageApi = (typeof browser !== 'undefined' ? browser : chrome).storage.local;
    const { losslessTrace } = await storageApi.get(['losslessTrace']);
    return losslessTrace === true;
  } catch { return false; }
}

// ----- Per-run state (held in memory on the service worker) ------------------
//
// A run lives only as long as its processMessage() call. If the SW gets
// evicted mid-run we lose the in-memory seq counter, but since we ended up
// awakened for each tool call anyway, the counter is refreshed from disk
// on the first write of each wake cycle via `_peekSeq`.

const _runState = new Map(); // runId -> { seq, model, providerId, ... }
const _runWriteQueues = new Map(); // runId -> serialized event-write promise

function _queueRunWrite(runId, write) {
  if (!runId) return Promise.resolve();
  const previous = _runWriteQueues.get(runId) || Promise.resolve();
  const current = previous.catch(() => {}).then(write);
  _runWriteQueues.set(runId, current);
  current.finally(() => {
    if (_runWriteQueues.get(runId) === current) _runWriteQueues.delete(runId);
  }).catch(() => {});
  return current;
}

async function _flushRunWrites(runId) {
  let pending = _runWriteQueues.get(runId);
  while (pending) {
    await pending.catch(() => {});
    const next = _runWriteQueues.get(runId);
    if (!next || next === pending) return;
    pending = next;
  }
}

async function _peekSeq(db, runId) {
  // Find the max seq already in the events store for this runId.
  const t = tx(db, ['events'], 'readonly');
  const idx = t.objectStore('events').index('runId');
  const cursor = idx.openCursor(IDBKeyRange.only(runId), 'prev');
  const result = await new Promise((resolve) => {
    cursor.onsuccess = () => resolve(cursor.result ? cursor.result.value.seq : 0);
    cursor.onerror = () => resolve(0);
  });
  return result;
}

// Restore per-run flags after worker eviction from the durable run record so
// the lossless tier decision survives a worker restart mid-run.
async function peekRunFlags(db, runId) {
  try {
    const record = await promisifyReq(
      tx(db, ['runs'], 'readonly').objectStore('runs').get(runId),
    );
    return { lossless: record?.lossless === true, losslessBytes: record?.losslessBytes || 0, losslessBytesEncoding: record?.losslessBytesEncoding || '' };
  } catch { return { lossless: false, losslessBytes: 0 }; }
}

const _runStateLoads = new Map();

async function _ensureRunState(runId, db = null) {
  if (!runId) return null;
  const existing = _runState.get(runId);
  if (existing) return existing;
  const pending = _runStateLoads.get(runId);
  if (pending) return pending;
  const load = (async () => {
    try {
      const resolvedDb = db || await openDB();
      const seq = await _peekSeq(resolvedDb, runId);
      const flags = await peekRunFlags(resolvedDb, runId);
      const state = { seq, lossless: flags.lossless, losslessBytes: Number(flags.losslessBytes) || 0, losslessBytesEncoding: flags.losslessBytesEncoding };
      _runState.set(runId, state);
      return state;
    } catch { return null; }
  })();
  _runStateLoads.set(runId, load);
  try { return await load; }
  finally { if (_runStateLoads.get(runId) === load) _runStateLoads.delete(runId); }
}

function boundedToolNames(tools) {
  return Array.isArray(tools)
    ? tools.slice(0, 100).map(tool => String(tool?.function?.name || '?').slice(0, 120))
    : [];
}

function clampLosslessRequest(messages, tools, maxBytes = LOSSILESS_REQUEST_CAP) {
  const request = { messages: messages ?? null, tools: tools ?? null };
  let serialized;
  try { serialized = JSON.stringify(request); } catch { serialized = null; }
  if (!serialized) {
    return {
      messages: { _truncated: true, length: null, head: '(unserializable request)', toolNames: boundedToolNames(tools) },
      tools: null,
    };
  }
  const byteLength = utf8ByteLength(serialized);
  const limit = Math.max(0, Math.min(LOSSILESS_REQUEST_CAP, Number(maxBytes) || 0));
  if (byteLength <= limit) return { messages, tools };
  // Keep one bounded head of the combined request. Tool names remain visible
  // even when the head ends before the dynamic tool catalog.
  const toolNames = boundedToolNames(tools);
  const buildMarker = head => ({
    messages: {
      _truncated: true,
      length: byteLength,
      head,
      toolNames,
    },
    tools: null,
  });
  while (toolNames.length && utf8ByteLength(JSON.stringify(buildMarker(''))) > limit) {
    toolNames.pop();
  }
  const head = fitUtf8Prefix(serialized, limit, prefix => JSON.stringify(buildMarker(prefix)));
  return buildMarker(head);
}

function boundedLosslessRequestMetadata(data) {
  const metadata = {};
  for (const [key, limit] of [
    ['providerClass', 160],
    ['providerId', 160],
    ['model', 240],
    ['phase', 40],
  ]) {
    const value = String(data?.[key] || '').trim();
    if (value) metadata[key] = value.slice(0, limit);
  }
  for (const key of [
    'attempt',
    'messageCount',
    'toolsCount',
    'imageBlockCount',
    'documentBlockCount',
  ]) {
    const value = Number(data?.[key]);
    if (Number.isFinite(value)) metadata[key] = Math.max(0, Math.min(1_000_000, Math.trunc(value)));
  }
  if (data?.repair === true) metadata.repair = true;
  if (data?.localWikipediaRag && typeof data.localWikipediaRag === 'object') {
    const rag = data.localWikipediaRag;
    metadata.localWikipediaRag = {
      status: String(rag.status || '').slice(0, 40),
      attempted: rag.attempted === true,
      matchCount: Math.max(0, Math.min(1_000_000, Math.trunc(Number(rag.matchCount) || 0))),
      multiSource: rag.multiSource === true,
      archiveDates: (Array.isArray(rag.archiveDates) ? rag.archiveDates : [])
        .slice(0, 3)
        .map(value => String(value || '').slice(0, 20)),
    };
  }
  return metadata;
}

function losslessBudgetMarker(kind, data) {
  const budgetHead = '(per-run lossless budget reached)';
  if (kind === 'llm_request') {
    let length = data?.messages?._truncated ? data.messages.length : null;
    if (length == null) {
      try { length = utf8ByteLength(JSON.stringify({ messages: data?.messages ?? null, tools: data?.tools ?? null })); } catch {}
    }
    const toolNames = Array.isArray(data?.messages?.toolNames)
      ? data.messages.toolNames.slice(0, 100).map(value => String(value || '?').slice(0, 120))
      : boundedToolNames(data?.tools);
    return {
      step: data?.step ?? null,
      ...boundedLosslessRequestMetadata(data),
      lossless: true,
      messages: { _truncated: true, length, head: budgetHead, toolNames },
      tools: null,
      losslessBudgetOmitted: true,
    };
  }

  let length = data?.result?._truncated ? data.result.length : null;
  if (length == null) {
    try { length = utf8ByteLength(JSON.stringify(data?.result)); } catch {}
  }
  return {
    step: data?.step ?? null,
    name: String(data?.name || '').slice(0, 120),
    args: null,
    result: { _truncated: true, length, head: budgetHead },
    latencyMs: data?.latencyMs ?? null,
    losslessBudgetOmitted: true,
  };
}

function _repairRunInTransaction(db, runId, { now, staleAfterMs }) {
  return new Promise((resolve, reject) => {
    const transaction = tx(db, ['runs', 'events'], 'readwrite');
    const runsStore = transaction.objectStore('runs');
    const eventsStore = transaction.objectStore('events');
    let run = null;
    let events = null;
    let pending = 2;
    let repairedRunId = null;
    let requestError = null;

    const fail = (error) => {
      requestError = error || new Error('trace repair request failed');
      try { transaction.abort(); } catch {}
    };
    const apply = () => {
      pending -= 1;
      if (pending > 0 || requestError) return;
      const plan = buildTraceRepairPlan(run, events, { now, staleAfterMs });
      if (!plan) return;
      // Last-instant liveness check: a run resumed between the candidate scan
      // and this transaction has registered itself in memory again.
      if (_runState.has(runId)) return;
      for (const event of plan.events) eventsStore.put(event);
      runsStore.put(plan.run);
      repairedRunId = runId;
    };

    transaction.oncomplete = () => resolve(repairedRunId);
    transaction.onerror = () => reject(requestError || transaction.error || new Error('trace repair failed'));
    transaction.onabort = () => {
      if (requestError) reject(requestError);
      else if (!repairedRunId) resolve(null);
    };

    const runRequest = runsStore.get(runId);
    runRequest.onsuccess = () => { run = runRequest.result || null; apply(); };
    runRequest.onerror = () => fail(runRequest.error);
    const eventsRequest = eventsStore.index('runId').getAll(IDBKeyRange.only(runId));
    eventsRequest.onsuccess = () => { events = eventsRequest.result || []; apply(); };
    eventsRequest.onerror = () => fail(eventsRequest.error);
  });
}

function _newSeq(runId) {
  const st = _runState.get(runId);
  if (!st) return 0;
  st.seq += 1;
  return st.seq;
}

function normalizeTraceAttachments(attachments) {
  return (Array.isArray(attachments) ? attachments : []).slice(0, 20).map(attachment => ({
    kind: ['image', 'document', 'text'].includes(attachment?.kind) ? attachment.kind : 'document',
    name: String(attachment?.name || 'attachment').replace(/[\u0000-\u001f\u007f]/g, '').slice(0, 240),
    mimeType: String(attachment?.mimeType || '').slice(0, 120),
    size: Number.isFinite(Number(attachment?.size)) ? Math.max(0, Number(attachment.size)) : 0,
    source: attachment?.source === 'slash_screenshot' ? 'slash_screenshot' : 'user_upload',
  }));
}

// ----- Public API ------------------------------------------------------------

export async function startRun(meta) {
  if (!(await tracingEnabled())) return null;
  try {
    const db = await openDB();
    const runId = meta.runId || `run_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
    const lineage = normalizeRunHeader(meta) || {};
    // Tier is decided once per run: explicit caller override wins, otherwise
    // the opt-in setting. Never forced for local runs by default.
    const lossless = meta.lossless === true || await losslessTraceEnabled();
    const record = {
      runId,
      // Stable per-conversation id so the Traces UI can group sibling runs
      // (= turns of the same chat). Set by the agent from its conversationIds
      // map keyed by tabId. Older runs have null here — viewer treats those
      // as singletons.
      conversationId: meta.conversationId || null,
      // Lineage: which run/session this run was derived from. Root runs keep
      // null/0. Only allowlisted identifiers reach these fields (run-header.js).
      parentRunId: (lineage && lineage.parentRunId) || null,
      parentSessionId: (lineage && lineage.parentSessionId) || null,
      delegationDepth: effectiveDelegationDepth(lineage),
      startedAt: Date.now(),
      endedAt: null,
      durationMs: null,
      status: 'running',
      model: meta.model || '',
      providerId: meta.providerId || '',
      providerClass: meta.providerClass || '',
      webbrainVersion: meta.webbrainVersion || '',
      traceFormatVersion: TRACE_FORMAT_VERSION,
      runtimeConfig: normalizeRuntimeTraceConfig(meta.runtimeConfig),
      userMessage: meta.userMessage || '',
      tabUrl: meta.tabUrl || '',
      tabTitle: meta.tabTitle || '',
      mode: meta.mode || 'act',
      attachments: normalizeTraceAttachments(meta.attachments),
      ...(lossless ? { lossless: true, losslessBytes: 0, losslessBytesEncoding: 'utf8' } : {}),
      stepCount: 0,
      totalInputTokens: 0,
      totalOutputTokens: 0,
      llmRequestCount: 0,
      llmResponseCount: 0,
      toolCallCount: 0,
      visionSubCallCount: 0,
      errorCount: 0,
      retryCount: 0,
      totalLlmLatencyMs: 0,
      totalToolLatencyMs: 0,
      finalContent: null,
    };
    await promisifyReq(tx(db, ['runs']).objectStore('runs').put(record));
    _runState.set(runId, { seq: 0, model: record.model, providerId: record.providerId, lossless, losslessBytes: 0, losslessBytesEncoding: lossless ? 'utf8' : '' });
    return runId;
  } catch (e) {
    console.warn('[trace] startRun failed:', e);
    return null;
  }
}

function _putEventWithLosslessTotal(db, runId, event, losslessBytes) {
  return new Promise((resolve, reject) => {
    const transaction = tx(db, ['events', 'runs']);
    const eventsStore = transaction.objectStore('events');
    const runsStore = transaction.objectStore('runs');
    let totalUpdated = false;
    transaction.oncomplete = () => resolve(totalUpdated);
    transaction.onerror = () => reject(transaction.error || new Error('lossless trace write failed'));
    transaction.onabort = () => reject(transaction.error || new Error('lossless trace write aborted'));
    eventsStore.put(event);
    const runRequest = runsStore.get(runId);
    runRequest.onsuccess = () => {
      const run = runRequest.result;
      if (run?.lossless !== true) return;
      run.losslessBytes = losslessBytes;
      run.losslessBytesEncoding = 'utf8';
      runsStore.put(run);
      totalUpdated = true;
    };
  });
}

async function _appendEventNow(runId, kind, data) {
  if (!(await tracingEnabled())) return;
  try {
    const db = await openDB();
    const state = await _ensureRunState(runId, db);
    if (state?.lossless === true && state.losslessBytesEncoding !== 'utf8') {
      const run = await promisifyReq(tx(db, ['runs'], 'readonly').objectStore('runs').get(runId));
      if (run?.lossless === true) {
        state.losslessBytes = await _recomputeLosslessBytes(db, run, {
          refreshActiveState: false,
          trustMarkedCurrent: false,
        });
        state.losslessBytesEncoding = 'utf8';
      }
    }
    let resolvedData = typeof data === 'function' ? data(state) : data;
    let losslessBytes = 0;
    let losslessBudgetOmitted = false;
    if (state?.lossless === true && (kind === 'llm_request' || kind === 'tool')) {
      try { losslessBytes = new TextEncoder().encode(JSON.stringify(resolvedData)).length; } catch {}
      const remainingBytes = Math.max(0, LOSSILESS_RUN_CAP - (state.losslessBytes || 0));
      if (losslessBytes > remainingBytes) {
        resolvedData = losslessBudgetMarker(kind, resolvedData);
        losslessBudgetOmitted = true;
      }
    }
    const seq = _newSeq(runId);
    const ev = makeEvent(runId, seq, kind, resolvedData);
    if (!ev) {
      // Unknown kind or unserializable data: skip the write and surface the
      // bug at recording time instead of storing a ghost event.
      console.warn('[trace] dropped invalid event:', kind);
      return null;
    }
    if (state?.lossless === true && (kind === 'llm_request' || kind === 'tool')) {
      if (losslessBudgetOmitted) {
        await promisifyReq(tx(db, ['events']).objectStore('events').put(ev));
        return seq;
      }
      const bytes = losslessBytes;
      const nextLosslessBytes = (state.losslessBytes || 0) + bytes;
      const totalUpdated = await _putEventWithLosslessTotal(db, runId, ev, nextLosslessBytes);
      if (totalUpdated) {
        state.losslessBytes = nextLosslessBytes;
        state.losslessBytesEncoding = 'utf8';
        await evictOldestLosslessRuns(runId, bytes);
      }
    } else {
      await promisifyReq(tx(db, ['events']).objectStore('events').put(ev));
    }
    return seq;
  } catch (e) {
    console.warn('[trace] appendEvent failed:', e);
  }
}

// Retain the active run and evict completed lossless runs oldest first when
// their aggregate recorded payload crosses the global budget. A cached running
// total keeps under-budget writes free of any store-wide scan; the scan itself
// walks every run rather than a newest-N window so old lossless runs still
// count toward the budget and stay evictable.
let _losslessTotalEstimate = null;

async function _recomputeLosslessBytes(db, run, {
  refreshActiveState = true,
  trustMarkedCurrent = true,
} = {}) {
  const events = await promisifyReq(
    tx(db, ['events'], 'readonly').objectStore('events').index('runId')
      .getAll(IDBKeyRange.only(run.runId)),
  );
  let bytes = 0;
  for (const event of events || []) {
    if (event?.kind !== 'llm_request' && event?.kind !== 'tool') continue;
    if (event?.data?.losslessBudgetOmitted === true) continue;
    try { bytes += new TextEncoder().encode(JSON.stringify(event.data)).length; } catch {}
  }
  const runTx = tx(db, ['runs']);
  const runStore = runTx.objectStore('runs');
  const current = await promisifyReq(runStore.get(run.runId));
  if (current?.lossless === true) {
    if (trustMarkedCurrent && current.losslessBytesEncoding === 'utf8') {
      // A serialized append or another migration committed after our event
      // snapshot. Its atomic marker+total is newer, so never overwrite it.
      bytes = Number(current.losslessBytes) || 0;
    } else if ((Number(current.losslessBytes) || 0) !== bytes
        || current.losslessBytesEncoding !== 'utf8') {
      current.losslessBytes = bytes;
      current.losslessBytesEncoding = 'utf8';
      await promisifyReq(runStore.put(current));
    }
  }
  if (refreshActiveState && _runState.get(run.runId)?.lossless === true) {
    void _queueRunWrite(run.runId, async () => {
      const refreshedBytes = await _recomputeLosslessBytes(db, run, {
        refreshActiveState: false,
        trustMarkedCurrent: false,
      });
      const state = _runState.get(run.runId);
      if (state?.lossless === true) {
        state.losslessBytes = refreshedBytes;
        state.losslessBytesEncoding = 'utf8';
      }
    });
  }
  return bytes;
}

async function _scanLosslessTotal() {
  const db = await openDB();
  const runs = [];
  await new Promise((resolve) => {
    const req = tx(db, ['runs'], 'readonly').objectStore('runs').openCursor();
    req.onsuccess = () => {
      const c = req.result;
      if (!c) return resolve();
      if (c.value?.lossless === true) runs.push(c.value);
      c.continue();
    };
    req.onerror = () => resolve();
  });
  let total = 0;
  for (const run of runs) {
    total += run.losslessBytesEncoding === 'utf8'
      ? Number(run.losslessBytes) || 0
      : await _recomputeLosslessBytes(db, run);
  }
  _losslessTotalEstimate = total;
  return total;
}

let _losslessBudgetQueue = Promise.resolve();

function evictOldestLosslessRuns(activeRunId, addedBytes = 0) {
  const rescan = _losslessTotalEstimate === null;
  const operation = _losslessBudgetQueue.then(() => _evictOldestLosslessRuns(activeRunId, addedBytes, rescan));
  _losslessBudgetQueue = operation.catch(() => {});
  return operation;
}

async function _evictOldestLosslessRuns(activeRunId, addedBytes, rescan) {
  if (rescan || _losslessTotalEstimate === null) {
    // First lossless write of this worker lifetime: learn the true total.
    // The persisted run record already includes this write's bytes.
    await _scanLosslessTotal();
  } else {
    _losslessTotalEstimate += addedBytes;
    if (_losslessTotalEstimate <= LOSSILESS_TOTAL_CAP) return;
  }
  const db = await openDB();
  const runs = [];
  await new Promise((resolve) => {
    const req = tx(db, ['runs'], 'readonly').objectStore('runs').openCursor();
    req.onsuccess = () => {
      const c = req.result;
      if (!c) return resolve();
      if (c.value?.lossless === true) runs.push(c.value);
      c.continue();
    };
    req.onerror = () => resolve();
  });
  let total = runs.reduce((sum, run) => sum + (Number(run.losslessBytes) || 0), 0);
  const candidates = runs
    .filter(run => run.runId !== activeRunId && run.status !== 'running')
    .sort((a, b) => (a.startedAt || 0) - (b.startedAt || 0));
  for (const run of candidates) {
    if (total <= LOSSILESS_TOTAL_CAP) break;
    await deleteRun(run.runId);
    total -= Number(run.losslessBytes) || 0;
  }
  _losslessTotalEstimate = total;
}

function _appendEvent(runId, kind, data) {
  return _queueRunWrite(runId, () => _appendEventNow(runId, kind, data));
}

export function recordLLMRequest(runId, step, payload, provenanceInput = null) {
  // Lossless tier (opt-in): persist the request's full message/tool shape for
  // deep debugging and request reconstruction. Clamp oversized requests so
  // one request cannot exhaust IndexedDB.
  return _appendEvent(runId, 'llm_request', (state) => {
    if (state?.lossless === true && provenanceInput) {
      if ((state.losslessBytes || 0) >= LOSSILESS_RUN_CAP) {
        let length = null;
        try { length = utf8ByteLength(JSON.stringify({ messages: provenanceInput.messages || null, tools: provenanceInput.tools || null })); } catch {}
        return { step, ...payload, lossless: true, messages: { _truncated: true, length, head: '(per-run lossless budget reached)', toolNames: boundedToolNames(provenanceInput.tools) }, tools: null };
      }
      const remainingBytes = Math.max(0, LOSSILESS_RUN_CAP - (state.losslessBytes || 0));
      const { messages, tools } = clampLosslessRequest(
        provenanceInput.messages || null,
        provenanceInput.tools || null,
        Math.min(LOSSILESS_REQUEST_CAP, remainingBytes),
      );
      return { step, ...payload, lossless: true, messages, tools };
    }
    // Default tier: never persist full prompts, message text, tool schemas, or
    // tool names here.
    // The optional fourth argument is reduced to content-free provenance only.
    let promptProvenance = null;
    if (provenanceInput) {
      try { promptProvenance = buildPromptTraceProvenance(provenanceInput.messages, provenanceInput.tools, provenanceInput.runtimeMode); } catch {}
    }
    return { step, ...payload, ...(promptProvenance ? { promptProvenance } : {}) };
  });
}

export function recordLLMResponse(runId, step, { content, toolCalls, usage, latencyMs, model, phase, attempt, repair }) {
  return _appendEvent(runId, 'llm_response', {
    step,
    content: content || null,
    toolCalls: toolCalls ? toolCalls.map(tc => ({
      id: tc.id,
      name: tc.function?.name,
      args: tc.function?.arguments, // string form, as received
    })) : [],
    usage: usage || null,
    latencyMs: latencyMs || null,
    model: model || null,
    // Carry the phase label (e.g. 'planner') so a pre-loop planner call recorded
    // at step 0 is distinguishable from the agent loop's first step-0 response.
    ...(phase ? { phase } : {}),
    ...(Number.isInteger(attempt) ? { attempt } : {}),
    ...(repair === true ? { repair: true } : {}),
  });
}

export function recordToolCall(runId, step, { name, args, result, latencyMs }) {
  // Truncate very large tool results (a11y trees can be huge). Keep the first
  // 20KB verbatim by default — plenty for debugging flow — and 200KB in the
  // opt-in lossless tier; note the truncation either way.
  return _appendEvent(runId, 'tool', (state) => {
    if (state?.lossless === true && (state.losslessBytes || 0) >= LOSSILESS_RUN_CAP) {
      let length = null;
      try { const s = JSON.stringify(result); length = s ? utf8ByteLength(s) : 0; } catch {}
      return { step, name, args: args || null, result: { _truncated: true, length, head: '(per-run lossless budget reached)' }, latencyMs: latencyMs || null };
    }
    const remainingBytes = Math.max(0, LOSSILESS_RUN_CAP - (state?.losslessBytes || 0));
    const cap = state?.lossless === true
      ? Math.min(LOSSILESS_RESULT_CAP, remainingBytes)
      : 20_000;
    const shortResult = clampUtf8Value(result, cap);
    return { step, name, args: args || null, result: shortResult, latencyMs: latencyMs || null };
  });
}

export function recordScreenshot(runId, step, dataUrl, caption = '') {
  return _queueRunWrite(runId, async () => {
    if (!(await tracingEnabledForRun(runId))) return;
    if (!dataUrl) return;
    try {
      const db = await openDB();
      await _ensureRunState(runId, db);
      const seq = _newSeq(runId);
      // Decode data URL to a Blob so IDB stores raw bytes (no base64 overhead).
      let blob = null;
      try {
        const resp = await fetch(dataUrl);
        blob = await resp.blob();
      } catch {
        // Fall back to storing the data URL as text.
      }
      const shot = { runId, seq, ts: Date.now(), caption, step, blob, dataUrl: blob ? null : dataUrl };
      await promisifyReq(tx(db, ['shots']).objectStore('shots').put(shot));
      // Also record a lightweight marker in the events log so the timeline
      // renders screenshots in order with everything else.
      const marker = makeEvent(runId, seq, 'screenshot', { step, caption });
      if (marker) {
        await promisifyReq(tx(db, ['events']).objectStore('events').put(marker));
      }
      return seq;
    } catch (e) {
      console.warn('[trace] recordScreenshot failed:', e);
    }
  });
}

export function recordError(runId, step, phase, message, code) {
  const data = { step, phase, message: formatErrorMessage(message) };
  if (code) data.code = normalizeErrorCode(code);
  return _appendEvent(runId, 'error', data);
}

// Turn/step boundary events: one turn per user message plus final answer, one
// step per LLM request. They give the event log explicit lifecycle structure —
// "which step failed, with what code" — instead of deriving it from payloads.
export function recordTurnStart(runId, step, payload = {}) {
  return _appendEvent(runId, 'turn_start', { step, ...payload });
}

export function recordTurnEnd(runId, step, payload = {}) {
  return _appendEvent(runId, 'turn_end', { step, ...payload });
}

export function recordStepStart(runId, step, payload = {}) {
  return _appendEvent(runId, 'step_start', { step, ...payload });
}

export function recordStepEnd(runId, step, payload = {}) {
  return _appendEvent(runId, 'step_end', { step, ...payload });
}

/**
 * Record the lifecycle of an interactive Ask streaming attempt without
 * persisting token contents. Payloads contain only decision/outcome codes,
 * protocol, aggregate counts, timing, and a redacted error summary.
 */
export function recordStreaming(runId, step, payload = {}) {
  return _appendEvent(runId, 'streaming', { step, ...payload });
}

/**
 * Record a vision sub-call: the agent asked a dedicated vision model to
 * describe a screenshot so the main planning model receives text instead
 * of pixels. Captured for debugging and quality inspection — description
 * quality is the main failure mode of the split-provider design.
 */
export function recordVisionSubCall(runId, { step, context, model, baseUrl, description, latencyMs, error }) {
  return _appendEvent(runId, 'vision_sub_call', {
    step: step || null,
    context: context || null, // 'initial_user_message' | 'auto_screenshot' | ...
    model: model || null,
    baseUrl: baseUrl || null,
    description: description || null,
    latencyMs: latencyMs || null,
    error: error || null,
  });
}

export function recordNote(runId, step, note, extra = null) {
  return _appendEvent(runId, 'note', { step, note, extra });
}

async function _retryCount(db, runId, step) {
  let count = 0;
  await new Promise((resolve) => {
    const idx = tx(db, ['events'], 'readonly').objectStore('events').index('runId');
    const req = idx.openCursor(IDBKeyRange.only(runId));
    req.onsuccess = () => {
      const cursor = req.result;
      if (!cursor) return resolve();
      const event = cursor.value;
      if (event?.kind === 'note'
          && event.data?.note === 'llm_retry'
          && event.data?.step === step) count += 1;
      cursor.continue();
    };
    req.onerror = () => resolve();
  });
  return count;
}

export function recordLLMRetry(runId, step, { delayMs = 0, code = 'UNKNOWN' } = {}) {
  return _queueRunWrite(runId, async () => {
    if (!(await tracingEnabled())) return;
    try {
      const db = await openDB();
      if (!_runState.has(runId)) {
        const seq = await _peekSeq(db, runId);
        _runState.set(runId, { seq });
      }
      const attempt = (await _retryCount(db, runId, step)) + 1;
      return _appendEventNow(runId, 'note', {
        step,
        note: 'llm_retry',
        extra: { attempt, delayMs, code: normalizeErrorCode(code) },
      });
    } catch (e) {
      console.warn('[trace] recordLLMRetry failed:', e);
    }
  });
}

export async function endRun(runId, { status = 'done', finalContent = null } = {}) {
  if (!runId) return;
  // Drain writes that enqueue migration refreshes while settling, then place
  // finalization at the tail of the same run queue.
  await _flushRunWrites(runId);
  // Finalization is a write in the same per-run sequence as events and any
  // migration refresh queued while those event writes are still settling.
  return _queueRunWrite(runId, async () => {
    try {
      if (!(await tracingEnabled())) return;
      const db = await openDB();
      // Tally usage from events. `totalCost` is the sum of `usage.cost`
      // across all llm_response events — providers report this in their
      // native units (OpenRouter & OpenAI: USD).
      const stats = createTraceStats();
      let sawLoopError = false;
      await new Promise((resolve) => {
        const idx = tx(db, ['events'], 'readonly').objectStore('events').index('runId');
        const req = idx.openCursor(IDBKeyRange.only(runId));
        req.onsuccess = () => {
          const c = req.result;
          if (!c) return resolve();
          const ev = c.value;
          if (ev.kind === 'error' && ev.data?.phase === 'loop') sawLoopError = true;
          addTraceEvent(stats, ev);
          c.continue();
        };
        req.onerror = () => resolve();
      });
      // Keep the read and write in one transaction so byte migration cannot
      // land between a stale snapshot and finalization's whole-record update.
      const runTx = tx(db, ['runs']);
      const runStore = runTx.objectStore('runs');
      const existing = await promisifyReq(runStore.get(runId));
      if (existing) {
        const finalStatus = status === 'done' && sawLoopError ? 'loop_stopped' : status;
        existing.endedAt = Date.now();
        existing.durationMs = existing.endedAt - existing.startedAt;
        existing.status = finalStatus;
        existing.finalContent = finalContent;
        existing.stepCount = stats.stepCount;
        existing.totalInputTokens = stats.totalInputTokens;
        existing.totalOutputTokens = stats.totalOutputTokens;
        existing.totalCost = stats.totalCost;
        existing.llmRequestCount = stats.llmRequestCount;
        existing.llmResponseCount = stats.llmResponseCount;
        existing.toolCallCount = stats.toolCallCount;
        existing.visionSubCallCount = stats.visionSubCallCount;
        existing.errorCount = stats.errorCount;
        existing.retryCount = stats.retryCount;
        existing.totalLlmLatencyMs = stats.totalLlmLatencyMs;
        existing.totalToolLatencyMs = stats.totalToolLatencyMs;
        await promisifyReq(runStore.put(existing));
      }
    } catch (e) {
      console.warn('[trace] endRun failed:', e);
    } finally {
      _runState.delete(runId);
    }
  });
}

/**
 * Repair trace records left running after a service-worker eviction. Each run
 * is re-read and updated in one transaction so a concurrent normal completion
 * wins, and a second repair pass cannot append duplicate terminal events.
 */
async function _listStaleRunCandidates(db, cutoff) {
  // Only runs old enough to be stale can qualify (last activity is never
  // older than startedAt), so scan just that slice of the startedAt index
  // instead of every run on record.
  const out = [];
  await new Promise((resolve, reject) => {
    const idx = tx(db, ['runs'], 'readonly').objectStore('runs').index('startedAt');
    const req = idx.openCursor(IDBKeyRange.upperBound(cutoff));
    req.onsuccess = () => {
      const c = req.result;
      if (!c) return resolve();
      const row = c.value;
      if (row?.status === 'running' && !row.repairedBy) out.push(row);
      c.continue();
    };
    req.onerror = () => reject(req.error || new Error('stale-run scan failed'));
  });
  return out;
}

export async function repairStaleRuns({
  now = Date.now(),
  staleAfterMs = TRACE_REPAIR_STALE_AFTER_MS,
} = {}) {
  if (typeof indexedDB === 'undefined') return [];
  if (!Number.isFinite(Number(now))) return [];
  try {
    const db = await openDB();
    const cutoff = Number(now) - normalizedThreshold(staleAfterMs);
    const candidates = await _listStaleRunCandidates(db, cutoff);
    const repaired = [];
    for (const candidate of candidates) {
      if (!isStaleRunningTrace(candidate, { now, staleAfterMs })) continue;
      // A live run in this background instance is still owned by the agent.
      // The durable marker handles races from another extension page.
      if (_runState.has(candidate.runId)) continue;
      await _flushRunWrites(candidate.runId);
      try {
        const repairedRunId = await _repairRunInTransaction(db, candidate.runId, { now, staleAfterMs });
        if (repairedRunId) repaired.push(repairedRunId);
      } catch (e) {
        console.warn('[trace] stale-run repair failed:', e);
      }
    }
    return repaired;
  } catch (e) {
    console.warn('[trace] stale-run scan failed:', e);
    return [];
  }
}

// ----- Reader API (used by traces.html) --------------------------------------

export async function listRuns({ limit = 500, conversationId = null } = {}) {
  const db = await openDB();
  const store = tx(db, ['runs'], 'readonly').objectStore('runs');
  const sessionQuery = Boolean(conversationId && store.indexNames.contains('sessionId'));
  const idx = store.index(sessionQuery ? 'sessionId' : 'startedAt');
  const out = [];
  // When conversationId is set, only matching runs count toward `limit`, so a
  // chat's tool-chain export is not starved by unrelated newer runs.
  await new Promise((resolve, reject) => {
    const req = sessionQuery
      ? idx.openCursor(IDBKeyRange.only(conversationId))
      : idx.openCursor(null, 'prev');
    req.onsuccess = () => {
      const c = req.result;
      if (!c || (!sessionQuery && out.length >= limit)) return resolve();
      const row = c.value;
      if (sessionQuery || !conversationId || row?.conversationId === conversationId) out.push(row);
      c.continue();
    };
    req.onerror = () => reject(req.error || new Error('listRuns failed'));
  });
  if (sessionQuery) out.sort((a, b) => (b.startedAt || 0) - (a.startedAt || 0));
  return out.slice(0, limit);
}

export async function getSessionStats(conversationId, { limit = 500 } = {}) {
  if (!conversationId) return aggregateTraceRuns([]);
  const runs = await listRuns({ limit, conversationId });
  return aggregateTraceRuns(runs);
}

export async function getRun(runId) {
  const db = await openDB();
  return promisifyReq(tx(db, ['runs'], 'readonly').objectStore('runs').get(runId));
}

export async function getRunEvents(runId) {
  const db = await openDB();
  const idx = tx(db, ['events'], 'readonly').objectStore('events').index('runId');
  const out = [];
  await new Promise((resolve, reject) => {
    const req = idx.openCursor(IDBKeyRange.only(runId));
    req.onsuccess = () => {
      const c = req.result;
      if (!c) return resolve();
      out.push(c.value);
      c.continue();
    };
    req.onerror = () => reject(req.error || new Error('getRunEvents failed'));
  });
  out.sort((a, b) => a.seq - b.seq);
  return out;
}

export async function getScreenshot(runId, seq) {
  const db = await openDB();
  return promisifyReq(tx(db, ['shots'], 'readonly').objectStore('shots').get([runId, seq]));
}

export async function deleteRun(runId) {
  const db = await openDB();
  const t = tx(db, ['runs', 'events', 'shots']);
  await promisifyReq(t.objectStore('runs').delete(runId));
  // Delete all events and shots for this runId via cursor
  await new Promise((resolve) => {
    const req = t.objectStore('events').index('runId').openCursor(IDBKeyRange.only(runId));
    req.onsuccess = () => {
      const c = req.result;
      if (!c) return resolve();
      c.delete();
      c.continue();
    };
    req.onerror = () => resolve();
  });
  await new Promise((resolve) => {
    const req = t.objectStore('shots').index('runId').openCursor(IDBKeyRange.only(runId));
    req.onsuccess = () => {
      const c = req.result;
      if (!c) return resolve();
      c.delete();
      c.continue();
    };
    req.onerror = () => resolve();
  });
}

export async function clearAllRuns() {
  _losslessTotalEstimate = null;
  const db = await openDB();
  const t = tx(db, ['runs', 'events', 'shots']);
  await promisifyReq(t.objectStore('runs').clear());
  await promisifyReq(t.objectStore('events').clear());
  await promisifyReq(t.objectStore('shots').clear());
}
